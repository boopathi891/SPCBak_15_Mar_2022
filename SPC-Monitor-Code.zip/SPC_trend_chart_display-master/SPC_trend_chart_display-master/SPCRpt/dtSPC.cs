﻿namespace SPCRpt
{


    public partial class dtSPC
    {
    }
}
